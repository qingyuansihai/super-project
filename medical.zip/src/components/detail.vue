<template>
	<div>
		detail
	</div>
</template>

<script >
	export default {
		
	}
</script>

<style scoped>


</style>