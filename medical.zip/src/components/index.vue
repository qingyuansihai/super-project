<template>
	<div>
		indexrfhfdhsfhg{{name}}
	</div>
</template>

<script >
	export default {
		data(){
			return{
			name:'lihaibo'
		}
		}
	}
</script>

<style scoped>


</style>